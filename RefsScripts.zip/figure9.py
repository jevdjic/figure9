#!/usr/bin/env python
# coding: utf-8

import os
import sys
import pandas as pd
import matplotlib.pyplot as plt
import editdistance
from glob import glob
import sys
import re
import multiprocessing as mp


TARGET_PARAGRAPH=int(sys.argv[1])
ALL_STRANDS=str(TARGET_PARAGRAPH)+'.fastq'

ALL_REFS='all_refs.txt'
TARGET_REFS=str(TARGET_PARAGRAPH)+'_refs.txt'

all_reads = pd.read_csv(ALL_STRANDS,names=['reads']) # FILE CONTAINING THE READS
all_reads['pos']=all_reads.index
all_reads['ActualRef']=9999
all_reads['editDist']=9999
all_reads['Paragraph']=999


my_file = open(ALL_REFS, "r") # FILE CONTAINING ALL THE REFERENCES
refs_all = my_file.readlines()

TOTAL_READS=len(all_reads)
TOTAL_REFS=len(refs_all)

# IF YOU WANT TO USE EDIT DISTANCE <-- Better results
counter1 = 0
counter2 = 0
content=[]
line_ids=[]
for x in range(TOTAL_READS//100):
    line_ids.append(x) 

with open(ALL_STRANDS, "r+") as infile: # FILE CONTAINING THE READS
    content = infile.readlines()


def one_batch(line_nr):
    min_line=line_nr*100   
    max_line=min_line+100
    if max_line>TOTAL_READS:
        max_line=TOTAL_READS
    res=[]
    for line_id in range(min_line, max_line):
        line=content[line_id]
        counter3 = 0
        closest_ref = 9999
        least_dist = 999
        for x in refs_all:
            dist = editdistance.eval(line[0:150],x[0:150])
            if dist < least_dist:
                least_dist = dist
                closest_ref = counter3
                if least_dist < 5:
                    break
            counter3 = counter3 + 1
         
        res.append(line_id)
        res.append(closest_ref)
        res.append(least_dist)      
    return res

    
#pool = mp.Pool(mp.cpu_count())
pool = mp.Pool(50)
results = pool.map_async(one_batch, line_ids).get()
pool.close()

for res in results:
   num=len(res)//3
   for i in range(num):
       line_id     = res[3*i]
       closest_ref = res[3*i+1]
       least_dist  = res[3*i+2]
       all_reads['ActualRef'][line_id] = closest_ref
       all_reads['editDist'][line_id] = least_dist


my_file = open(TARGET_REFS, "r") # FILE CONTAINING THE TARGET REFERENCES
refs_target = my_file.readlines()


TOTAL_READS=len(all_reads)

for x in range(TOTAL_READS):
    a = all_reads['ActualRef'][x]//15
    all_reads['Paragraph'][x] = a

counter1 = 0
counter2 = 0
with open(ALL_STRANDS, "r+") as infile:
    content = infile.readlines()
    for line in content:
        for x in refs_target:
            dist = editdistance.eval(line[0:150],x[0:150])
            if dist <= all_reads['editDist'][counter1]:
                all_reads['Paragraph'][counter1] = TARGET_PARAGRAPH
                all_reads['editDist'][counter1] = dist
            
        counter1 = counter1 + 1
        


all_reads.to_csv(str(TARGET_PARAGRAPH)+'_backupfinal.txt')

brr = all_reads['Paragraph'].value_counts()

img = str(TARGET_PARAGRAPH)+'_bargraph.pdf'

img2 = str(TARGET_PARAGRAPH)+'_piechart.pdf'

fig = plt.figure()
ax = fig.add_axes([0,0,3,3])
ax.tick_params(labelsize=30)
barlist = ax.bar(brr.index,brr/1000)
barlist[0].set_color('r')
plt.xlabel('Paragraph Number', fontsize=40, labelpad=30)
plt.ylabel('Number of Strands (in Thousands)', fontsize=40, labelpad=30)
plt.savefig(img,dpi=300,bbox_inches='tight')
plt.plot()
